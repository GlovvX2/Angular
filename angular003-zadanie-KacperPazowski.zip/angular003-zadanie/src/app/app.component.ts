import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PCComponent } from "./components/pc/pc.component";
import { ButtonMultiplicationComponent } from "./components/button-multiplication/button-multiplication.component";
import { IconViewerComponent } from "./components/icon-viewer/icon-viewer.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, PCComponent, ButtonMultiplicationComponent, IconViewerComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'angular003-zadanie';
}
