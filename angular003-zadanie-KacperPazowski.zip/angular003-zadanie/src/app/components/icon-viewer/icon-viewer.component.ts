import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-viewer',
  standalone: true,
  imports: [],
  templateUrl: './icon-viewer.component.html',
  styleUrl: './icon-viewer.component.css'
})
export class IconViewerComponent {
  BigImage:string = "images/git-blue.png";
  info()
  {
    this.BigImage = "images/git-blue.png";
  }
  plus()
  {
    this.BigImage = "images/git-green.png";
  }
  delete()
  {
    this.BigImage = "images/git-red.png";
  }
  alert()
  {
    this.BigImage = "images/git-yellow.png";
  }
}
