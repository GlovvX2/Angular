import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IconViewerComponent } from './icon-viewer.component';

describe('IconViewerComponent', () => {
  let component: IconViewerComponent;
  let fixture: ComponentFixture<IconViewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [IconViewerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IconViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
