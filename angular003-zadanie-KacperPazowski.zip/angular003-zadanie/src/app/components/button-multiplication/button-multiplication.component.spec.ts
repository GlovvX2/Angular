import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonMultiplicationComponent } from './button-multiplication.component';

describe('ButtonMultiplicationComponent', () => {
  let component: ButtonMultiplicationComponent;
  let fixture: ComponentFixture<ButtonMultiplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ButtonMultiplicationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ButtonMultiplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
