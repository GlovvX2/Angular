import { Component } from '@angular/core';

@Component({
  selector: 'app-button-multiplication',
  standalone: true,
  imports: [],
  templateUrl: './button-multiplication.component.html',
  styleUrl: './button-multiplication.component.css'
})
export class ButtonMultiplicationComponent {
  num:number = 1;
  More()
  {
    if(this.num<64)
      this.num=this.num*2;
  }
  Less()
  {
    if(this.num>1)
      this.num=this.num/2;
  }
}
