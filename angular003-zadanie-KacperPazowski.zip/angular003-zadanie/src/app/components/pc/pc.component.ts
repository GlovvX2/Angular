import { Component } from '@angular/core';

@Component({
  selector: 'app-pc',
  standalone: true,
  imports: [],
  templateUrl: './pc.component.html',
  styleUrl: './pc.component.css'
})
export class PCComponent {
  CPU: string = "Intel Core I5";
  RAM: number = 8;
  SSD: number = 240;
  GPU: string = "GeForce RTX 4080"
  Price:number = 2499;
}
