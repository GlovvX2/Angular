import { ListToDo } from "../models/list";
export const ListData:ListToDo[]=
[
    {toDo:"Zrób tosty",isItDone:false},
    {toDo:"Chleb",isItDone:false}
];