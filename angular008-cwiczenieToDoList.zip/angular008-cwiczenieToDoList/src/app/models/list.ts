export interface ListToDo {
    toDo:string;
    isItDone:boolean;
}
